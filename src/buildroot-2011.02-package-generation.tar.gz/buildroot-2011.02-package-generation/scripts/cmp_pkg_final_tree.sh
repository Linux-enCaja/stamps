#!/bin/sh
# The purpose of this script is to show you the difference between
# what has been packaged and what's in your final root filesystem.
# This give the ability to track down packages which install things
# directory into the target directory without using the package
# infrastructure.

if [ -z $1 ]; then
    echo "Missing output directory parameter"
    exit 1
fi

# Generate tree for packages
rm -f pkg_files.txt
for i in $1/packages/*target.tar.bz2; do
    tar tfj $i | tr -s " " | sed -e s,./,, | grep -v "^$" >> pkg_files.txt
done
cat pkg_files.txt | sort -u > pkg_files2.txt
mv pkg_files2.txt pkg_files.txt

# Generate tree for final image
tar tf $1/images/rootfs.tar | tr -s " " | sed -e s,./,, | grep -v "^$" | sort > img_files.txt
