
#ifndef __TS_H__
#define __TS_H__

void ts_init();
int ts_pressed();


#endif //__TS_H__
