Notes on bootstream-1.0
-----------------------

This is derived from Chumby source code with gaps filled in by hand. Some of it
is just guesswork.

**NB** This assumes you have installed an ARM GCC 4.3.2 toolchain as specified in
http://wiki.chumby.com/mediawiki/index.php/GNU_Toolchain

- bootstream-1.0/ is from Falconwing Software version 1.0.2, build 1.7.2370
  bootstream-1.0.tgz
  See http://files.chumby.com/source/
  
- bootstream/elftosb2/ contains the binary for elftosb2, as published by Freescale, 
  which is not contained in Chumby bootstream-1.0.tgz

- config/ is based on postings by Chumby on the Chumby forum 
  see http://forum.chumby.com/viewtopic.php?id=5056  

- images/ contains the output images in SB format  

Revisions

1   29/05/2010 13:56:05 
    Straight copy of Chumby code, no modificiations.
    This code will not run on Lyre-imx233 because we do not have SDRAM. 
    power_prep and clocks_prep may be wrong also
