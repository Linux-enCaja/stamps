/***************************************************************************
 *             __________               __   ___.
 *   Open      \______   \ ____   ____ |  | _\_ |__   _______  ___
 *   Source     |       _//  _ \_/ ___\|  |/ /| __ \ /  _ \  \/  /
 *   Jukebox    |    |   (  <_> )  \___|    < | \_\ (  <_> > <  <
 *   Firmware   |____|_  /\____/ \___  >__|_ \|___  /\____/__/\_ \
 *                     \/            \/     \/    \/            \/
 * $Id: codec_thread.h 23471 2009-11-01 19:39:23Z blue_dude $
 *
 * Copyright (C) 2005 Miika Pekkarinen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 ****************************************************************************/

#ifndef _CODEC_THREAD_H
#define _CODEC_THREAD_H

#include <stdbool.h>

int get_codec_base_type(int type);
const char *get_codec_filename(int cod_spec);
void codec_thread_do_callback(void (*fn)(void),
                              unsigned int *codec_thread_id);
void codec_init_codec_api(void);
void make_codec_thread(void);

#endif
