/***************************************************************************
 *
 *             __________               __   ___.
 *   Open      \______   \ ____   ____ |  | _\_ |__   _______  ___
 *   Source     |       _//  _ \_/ ___\|  |/ /| __ \ /  _ \  \/  /
 *   Jukebox    |    |   (  <_> )  \___|    < | \_\ (  <_> > <  <
 *   Firmware   |____|_  /\____/ \___  >__|_ \|___  /\____/__/\_ \
 *                     \/            \/     \/    \/            \/
 * $Id: playlist_viewer.h 24791 2010-02-20 19:06:39Z kugel $
 *
 * Copyright (C) 2003 Hardeep Sidhu
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 ****************************************************************************/

#ifndef _PLAYLIST_VIEWER_H_
#define _PLAYLIST_VIEWER_H_

enum playlist_viewer_result playlist_viewer(void);
enum playlist_viewer_result playlist_viewer_ex(const char* filename);
bool search_playlist(void);

enum playlist_viewer_result {
    PLAYLIST_VIEWER_OK,
    PLAYLIST_VIEWER_USB,
    PLAYLIST_VIEWER_MAINMENU,
};

#endif
