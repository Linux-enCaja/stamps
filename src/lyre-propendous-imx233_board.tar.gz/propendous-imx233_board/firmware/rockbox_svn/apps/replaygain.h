/***************************************************************************
 *             __________               __   ___.
 *   Open      \______   \ ____   ____ |  | _\_ |__   _______  ___
 *   Source     |       _//  _ \_/ ___\|  |/ /| __ \ /  _ \  \/  /
 *   Jukebox    |    |   (  <_> )  \___|    < | \_\ (  <_> > <  <
 *   Firmware   |____|_  /\____/ \___  >__|_ \|___  /\____/__/\_ \
 *                     \/            \/     \/    \/            \/
 * $Id: replaygain.h 18814 2008-10-15 06:38:51Z zagor $
 *
 * Copyright (C) 2005 Magnus Holmgren
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY
 * KIND, either express or implied.
 *
 ****************************************************************************/

#ifndef _REPLAYGAIN_H
#define _REPLAYGAIN_H

#include "metadata.h"

long get_replaygain_int(long int_gain);
long parse_replaygain(const char* key, const char* value,
    struct mp3entry* entry, char* buffer, int length);
long parse_replaygain_int(bool album, long gain, long peak,
    struct mp3entry* entry, char* buffer, int length);

#endif
